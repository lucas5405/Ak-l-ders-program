# Akıllı Ders Planlayıcı

Bu klasör Android Studio ile açılabilecek başlangıç Android projesidir.

## İçerik
- Ana ders planlayıcı ekranı
- YKS geri sayımı
- Ders seçimi
- TYT / AYT seçimi
- Test moduna geçişte yatay ekran
- Yatay test ekranında sol tarafta analog saat, sağ tarafta test süresi
- Mola ekranı
- Mola süresi seçenekleri
- YouTube butonu sadece seçilen TYT/AYT + ders için ders videosu araması açar
- Mola bitince "MOLA BİTTİ" ekranı
- Soru bankası ekleme/silme

## Android Studio
1. ZIP'i çıkar.
2. Android Studio > Open ile klasörü aç.
3. Gradle senkronizasyonunun bitmesini bekle.
4. Telefon veya emülatör bağla.
5. Run ile çalıştır.

Not: YKS geri sayım tarihi örnek olarak 21 Haziran 2027 10:15 olarak bırakılmıştır; resmi tarih kesinleştiğinde koddan güncellenebilir.
