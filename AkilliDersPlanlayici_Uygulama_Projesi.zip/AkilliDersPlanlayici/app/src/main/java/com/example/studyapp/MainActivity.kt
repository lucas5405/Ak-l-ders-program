package com.example.studyapp

import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

private val Black = Color.Black
private val Card = Color(0xFF121820)
private val Card2 = Color(0xFF1B222B)
private val Gray = Color(0xFF8C939B)
private val White = Color.White

private enum class Screen { HOME, TEST_SETUP, TEST, BREAK, BREAK_DONE, BANKS }

private data class QuestionBook(
    val name: String,
    val subject: String,
    val solved: Int = 0,
    val total: Int = 100
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudyApp() }
    }
}

@Composable
fun StudyApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    var selectedSubject by remember { mutableStateOf("Matematik") }
    var examType by remember { mutableStateOf("TYT") }
    var breakMinutes by remember { mutableStateOf(25) }
    var theme by remember { mutableStateOf(White) }

    var books by remember {
        mutableStateOf(
            listOf(
                QuestionBook("Matematik Soru Bankası", "Matematik", 65),
                QuestionBook("Fizik Denemeleri", "Fizik", 40),
                QuestionBook("Türkçe Paragraf", "Türkçe", 70),
                QuestionBook("Kimya Testleri", "Kimya", 50)
            )
        )
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = theme,
            background = Black,
            surface = Card
        )
    ) {
        when (screen) {
            Screen.HOME -> HomeScreen(
                primary = theme,
                books = books,
                onStart = { screen = Screen.TEST_SETUP },
                onBanks = { screen = Screen.BANKS },
                onDeleteBook = { book -> books = books - book }
            )

            Screen.BANKS -> BanksScreen(
                primary = theme,
                books = books,
                onBack = { screen = Screen.HOME },
                onAdd = {
                    books = books + QuestionBook(
                        "Yeni Soru Bankası ${books.size + 1}",
                        "Matematik"
                    )
                },
                onDelete = { book -> books = books - book }
            )

            Screen.TEST_SETUP -> TestSetupScreen(
                primary = theme,
                subject = selectedSubject,
                examType = examType,
                onSubject = { selectedSubject = it },
                onExam = { examType = it },
                onStart = { screen = Screen.TEST },
                onBack = { screen = Screen.HOME }
            )

            Screen.TEST -> TestScreen(
                primary = theme,
                subject = selectedSubject,
                onBreak = { screen = Screen.BREAK },
                onFinish = { screen = Screen.HOME }
            )

            Screen.BREAK -> BreakScreen(
                primary = theme,
                subject = selectedSubject,
                examType = examType,
                minutes = breakMinutes,
                onMinutes = { breakMinutes = it },
                onOpenYouTube = { },
                onFinished = { screen = Screen.BREAK_DONE },
                onCancel = { screen = Screen.TEST }
            )

            Screen.BREAK_DONE -> BreakDoneScreen(
                primary = theme,
                subject = selectedSubject,
                onContinue = { screen = Screen.TEST },
                onHome = { screen = Screen.HOME }
            )
        }
    }
}

@Composable
private fun HomeScreen(
    primary: Color,
    books: List<QuestionBook>,
    onStart: () -> Unit,
    onBanks: () -> Unit,
    onDeleteBook: (QuestionBook) -> Unit
) {
    var selectedDay by remember { mutableStateOf("Paz") }

    AppBackground {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Header(primary)
            Spacer(Modifier.height(14.dp))
            CountdownCard(primary)
            Spacer(Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz").forEach { day ->
                    DayChip(day, selectedDay == day, primary) { selectedDay = day }
                }
            }

            Spacer(Modifier.height(14.dp))
            Text("Bugünkü Ders", color = White, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(7.dp))
            CardBox {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Matematik", color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("Daha fazla net için çalışmaya devam et.", color = Gray, fontSize = 12.sp)
                    }
                    Text("›", color = primary, fontSize = 26.sp)
                }
            }

            Spacer(Modifier.height(12.dp))
            Button(
                onClick = onStart,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = primary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("▶  Test Modunu Başlat", color = Color.Black, fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Soru Bankalarım", color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onBanks) { Text("+", color = primary, fontSize = 22.sp) }
            }

            LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                items(books) { book ->
                    CardBox {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(book.name, color = White, fontWeight = FontWeight.Bold)
                                Text("${book.subject} • ${book.solved}/${book.total}", color = Gray, fontSize = 11.sp)
                            }
                            Text("${book.solved}%", color = primary, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(primary: Color) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("Akıllı Ders Planlayıcı", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Daha iyi bir gelecek, seninle başlar.", color = Gray, fontSize = 12.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            listOf(White, Color(0xFF9AA0A6), Color(0xFF38414B)).forEach {
                Box(Modifier.size(20.dp).clip(CircleShape).background(it))
            }
        }
    }
}

@Composable
private fun CountdownCard(primary: Color) {
    var text by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        while (true) {
            val target = LocalDateTime.of(2027, 6, 21, 10, 15)
            val now = LocalDateTime.now()
            val totalMinutes = ChronoUnit.MINUTES.between(now, target).coerceAtLeast(0)
            text = "${totalMinutes / 1440} Gün ${(totalMinutes % 1440) / 60} Saat ${totalMinutes % 60} Dk"
            delay(1000)
        }
    }
    CardBox {
        Text("YKS Kalan Süre", color = Gray, fontSize = 12.sp)
        Spacer(Modifier.height(4.dp))
        Text(text, color = primary, fontSize = 25.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun DayChip(day: String, selected: Boolean, primary: Color, onClick: () -> Unit) {
    Box(
        Modifier
            .width(45.dp)
            .height(38.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) primary else Card)
            .border(1.dp, Color(0xFF343C45), RoundedCornerShape(8.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(day, color = if (selected) Color.Black else White, fontSize = 11.sp)
    }
}

@Composable
private fun TestSetupScreen(
    primary: Color,
    subject: String,
    examType: String,
    onSubject: (String) -> Unit,
    onExam: (String) -> Unit,
    onStart: () -> Unit,
    onBack: () -> Unit
) {
    val subjects = listOf("Matematik", "Türkçe", "Fizik", "Kimya", "Biyoloji", "Tarih", "Coğrafya", "Edebiyat")
    val context = LocalContext.current

    AppBackground {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text("‹  Test Modu", color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("Hangi ders için test yapmak istiyorsun?", color = Gray, fontSize = 13.sp)
            Spacer(Modifier.height(18.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                items(subjects) { item ->
                    SelectRow(item, item == subject, primary) { onSubject(item) }
                }
            }

            Text("Sınav Türü", color = White, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(7.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("TYT", "AYT").forEach { type ->
                    Button(
                        onClick = { onExam(type) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (examType == type) primary else Card2
                        )
                    ) {
                        Text(type, color = if (examType == type) Color.Black else White)
                    }
                }
            }

            Spacer(Modifier.height(10.dp))
            Button(
                onClick = {
                    val activity = context as Activity
                    activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    onStart()
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = primary)
            ) {
                Text("Teste Geç", color = Color.Black, fontWeight = FontWeight.Bold)
            }

            TextButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
                Text("Geri", color = Gray)
            }
        }
    }
}

@Composable
private fun TestScreen(
    primary: Color,
    subject: String,
    onBreak: () -> Unit,
    onFinish: () -> Unit
) {
    val context = LocalContext.current
    var seconds by remember { mutableStateOf(60 * 60) }

    LaunchedEffect(Unit) {
        while (seconds > 0) {
            delay(1000)
            seconds--
        }
    }

    AppBackground {
        Row(
            Modifier.fillMaxSize().padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                Modifier.weight(1f).fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("ANALOG SAAT", color = Gray, fontSize = 11.sp)
                AnalogClock()
                Spacer(Modifier.height(8.dp))
                Text(
                    LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")),
                    color = White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Box(Modifier.width(1.dp).fillMaxHeight(0.8f).background(Color(0xFF303740)))

            Column(
                Modifier.weight(1f).fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("$subject Testi", color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text("TYT / AYT test süresi", color = Gray, fontSize = 12.sp)
                Spacer(Modifier.height(16.dp))
                Text(formatSeconds(seconds), color = primary, fontSize = 48.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(18.dp))

                Button(
                    onClick = {
                        android.widget.Toast.makeText(
                            context,
                            "Mola ekranı açılıyor",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                        onBreak()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = primary)
                ) {
                    Text("☕  Mola Ver", color = Color.Black, fontWeight = FontWeight.Bold)
                }

                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        val activity = context as Activity
                        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                        onFinish()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Card2)
                ) {
                    Text("Testi Bitir", color = White)
                }
            }
        }
    }
}

@Composable
private fun AnalogClock() {
    var now by remember { mutableStateOf(LocalTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalTime.now()
            delay(1000)
        }
    }
    Box(
        Modifier
            .size(190.dp)
            .clip(CircleShape)
            .border(3.dp, Color(0xFF56616C), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "${now.hour.toString().padStart(2, '0')}:${now.minute.toString().padStart(2, '0')}",
            color = White,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun BreakScreen(
    primary: Color,
    subject: String,
    examType: String,
    minutes: Int,
    onMinutes: (Int) -> Unit,
    onOpenYouTube: () -> Unit,
    onFinished: () -> Unit,
    onCancel: () -> Unit
) {
    val context = LocalContext.current
    var seconds by remember(minutes) { mutableStateOf(minutes * 60) }

    LaunchedEffect(minutes) {
        seconds = minutes * 60
        while (seconds > 0) {
            delay(1000)
            seconds--
        }
        onFinished()
    }

    AppBackground {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("☕", fontSize = 40.sp)
            Text("Mola Zamanı", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("$examType $subject", color = Gray, fontSize = 13.sp)
            Spacer(Modifier.height(12.dp))
            Text(formatSeconds(seconds), color = primary, fontSize = 52.sp, fontWeight = FontWeight.Bold)
            Text("Kalan süre", color = Gray)
            Spacer(Modifier.height(15.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf(5, 10, 15, 25, 30, 45, 60).forEach { m ->
                    FilterChip(
                        selected = minutes == m,
                        onClick = { onMinutes(m) },
                        label = { Text(if (m == 60) "1s" else "${m}d") }
                    )
                }
            }

            Spacer(Modifier.height(14.dp))
            Button(
                onClick = { openYouTube(context, subject, examType) },
                colors = ButtonDefaults.buttonColors(containerColor = primary)
            ) {
                Text("▶  YouTube'da Ders Videosu Ara", color = Color.Black, fontWeight = FontWeight.Bold)
            }
            Text(
                "Sadece ders videosu araması açılır: $examType $subject",
                color = Gray,
                fontSize = 11.sp
            )

            Spacer(Modifier.height(10.dp))
            Button(
                onClick = onCancel,
                colors = ButtonDefaults.buttonColors(containerColor = Card2)
            ) {
                Text("Molayı Bitir", color = White)
            }
        }
    }
}

@Composable
private fun BreakDoneScreen(
    primary: Color,
    subject: String,
    onContinue: () -> Unit,
    onHome: () -> Unit
) {
    AppBackground {
        Column(
            Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("✓", color = primary, fontSize = 70.sp, fontWeight = FontWeight.Bold)
            Text("MOLA BİTTİ!", color = White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Text("Dinlenme tamamlandı, teste geri dönebilirsin.", color = Gray)
            Text("Ders: $subject", color = Gray, fontSize = 12.sp)
            Spacer(Modifier.height(20.dp))
            Button(onClick = onContinue, colors = ButtonDefaults.buttonColors(containerColor = primary)) {
                Text("Teste Devam Et", color = Color.Black, fontWeight = FontWeight.Bold)
            }
            TextButton(onClick = onHome) { Text("Ana Ekrana Dön", color = Gray) }
        }
    }
}

@Composable
private fun BanksScreen(
    primary: Color,
    books: List<QuestionBook>,
    onBack: () -> Unit,
    onAdd: () -> Unit,
    onDelete: (QuestionBook) -> Unit
) {
    AppBackground {
        Column(Modifier.fillMaxSize().padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("‹  Soru Bankalarım", color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = primary)) {
                    Text("+", color = Color.Black)
                }
            }
            Spacer(Modifier.height(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(books) { book ->
                    CardBox {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(book.name, color = White, fontWeight = FontWeight.Bold)
                                Text("${book.subject} • ${book.solved}/${book.total}", color = Gray, fontSize = 11.sp)
                            }
                            TextButton(onClick = { onDelete(book) }) {
                                Text("Sil", color = Color(0xFFE57373))
                            }
                        }
                    }
                }
            }
            TextButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
                Text("Ana Ekrana Dön", color = Gray)
            }
        }
    }
}

@Composable
private fun SelectRow(text: String, selected: Boolean, primary: Color, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFF27313B) else Card)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(text, color = White, modifier = Modifier.weight(1f), fontSize = 16.sp)
            Text(if (selected) "✓" else "○", color = primary, fontSize = 20.sp)
        }
    }
}

@Composable
private fun CardBox(content: @Composable RowScope.() -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Card),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(Modifier.padding(13.dp), content = content)
    }
}

@Composable
private fun AppBackground(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Black),
        content = content
    )
}

private fun formatSeconds(total: Int): String {
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return "%02d:%02d:%02d".format(h, m, s)
}

private fun openYouTube(context: android.content.Context, subject: String, examType: String) {
    val query = Uri.encode("$examType $subject ders anlatımı")
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$query"))
    context.startActivity(intent)
}
